@extends('layout.app')
@section('content')
<br>
<br>
<br>
<br>
<h1 class="mt-5 text-center">Comming Soon</h1>
<br>
<br>
<br>
<br>
<br>
@endsection
