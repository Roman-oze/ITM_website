
<footer class="bg-dark text-white">
    <div class="p-4">
        <div class="row text-center">
            <div class="col-sm-6 text-sm-left small mb-4 mb-sm-0 text-left">
                <img src="{{ asset('frontend/image/logo.png')}}" alt="Logo of the PRB" class="mr-2 float-sm-left" width="40" height="40">
                <h3 class="font-weight-bold text-white pt-1 h5 mb-0">
                   ITM
                </h3>
            </div>
            <div class="col-sm-6 text-sm-right small mb-4 mb-sm-0 pt-sm-1">
                © Information Technology & Management ( I T M )
            </div>
        </div>
    </div>
    {{-- <div class="text-center small p-2 text-muted footer-dark">
        Designed &amp; Developed by <a href="https://github.com/Roman-oze/resume" class="text-reset font-weight-bold" target="_blank" rel="noopener">RomanOze</a>
    </div> --}}
</footer>
