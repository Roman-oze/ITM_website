<style>
.clubhead{
    text-align: center;
    background-color: #000000;
    height: 50px;
    }
      .clubtxt{
  font-size: 36px;
  color:white;
  }
    .card-body{
      text-align: center;
      width: auto;
    }
  
    .circular-image {
      display: block;
      margin: auto;
      overflow: hidden;
      width: auto;
      height: 204px; /* Adjust the size as needed */
     /* Adjust the size as needed */
    }

    .card:hover {
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      transform: scale(1.05);
    }

    .bgphoto{
      background-image:url("/model/slidebg.png");
      background-size: cover;
      background-position: center;
    }
    .bgcolor{
      background-image:linear-gradient(rgba(226, 220, 220, 0.589),#4eced3d0);
  
    }
  
    .faculty-card {
           border-radius: 24px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            max-width: 250px;
            width: 100%;
            transition: transform 0.3s;
            display: block;
            margin: auto;
            padding: 10px;
            border:2px double #3498db;
            height: auto;
        }
   
        .faculty-card:hover {
            transform: scale(1.05);
        }
  
  
        .faculty-card-content {
            padding: 20px;
        }
  
        .faculty-card h2 {
            margin-bottom: 10px;
            color: #333;
        }
        .faculty-card h3{
            margin-bottom: 10px;
            color: #333;
        }
  
        .faculty-card p {
            color: #777;
            margin-bottom: 5px;
        }
  
        .faculty-card a {
            text-decoration: none;
            color: #3498db;
            font-weight: bold;
        }
        h5{
            color: rgb(8, 145, 54);
        }
        h4{
          color: #463c3c;
        }
        .student-card {
        overflow: hidden;
        max-width: 250px;
        width: 100%;
        transition: transform 0.3s;
        display: block;
        margin: auto;
        padding: 10px;
    }
  
    .student-card:hover {
        transform: scale(1.05);
    }
        .head{
        background-color: #3498db;
     text-align: center;
        color: #fff;
        font-size: larger;
        font-family: Georgia, 'Times New Roman', Times, serif;
        border-radius: 10px;
        }
  /* Add styles for other sections as needed */
  .photo{
  height: auto;
  width: 100%;
  border-radius: 24px;
  }
  .back{
  height: 50px;
    width: 50px;
    border-radius: 100%;
  }
  .icon1{
    color: #000000;
    font-size:x-large;
    font-size: larger;

  }
  .icon1:hover{
    color: blue;
    font-size:x-large;
  }
</style>