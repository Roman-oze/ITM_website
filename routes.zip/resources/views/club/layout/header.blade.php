
<div class="container-fluid">
    <br><br><br><br>
    <div class="row mt-5">
        <div class="col-md-6 col-sm-12 text-center">
            <img src="{{asset('frontend/image/club-template0.png')}}" class="img-fluid animate__animated animate__fadeInLeft">
        </div>
        <div class="col-md-6 paragh col-sm-12 text-center">
            <h3 class="btnn animate__animated animate__bounce">Join Our Club</h3><br>
            <img src="{{asset('frontend/image/QR-code.png')}}" class="QR">
            <b><p class="p-3">"Follow, like, and share the official Facebook pages of the Department of Information Technology & Management and the ITM Club."</p></b>

            <div class="text-center d-flex flex-column flex-md-row justify-content-center align-items-center">
                <a href="https://www.facebook.com/islamfull.5" class="face mb-2 mb-md-0">Facebook <i class="fa-brands fa-facebook"></i></a>
                <a href="https://www.youtube.com/channel/UClBIz9HlgUBfzYvnj-xX2-w" class="tube ms-0 ms-md-2 mt-2">Youtube  <i class="fa-brands fa-youtube"></i></a>
            </div>

        </div>
    </div>
</div>
<br>

